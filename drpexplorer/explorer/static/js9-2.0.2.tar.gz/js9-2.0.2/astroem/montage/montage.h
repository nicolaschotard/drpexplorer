#ifndef MONTAGE
FILE *fstatus;
#define MONTAGE
#endif
